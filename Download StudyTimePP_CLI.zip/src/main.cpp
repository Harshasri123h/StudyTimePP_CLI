#include <iostream>
#include "auth.h"

int main() {
    std::cout << "Welcome to StudyTime++!\n";
    loginMenu();
    return 0;
}
