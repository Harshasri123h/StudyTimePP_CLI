#ifndef AUTH_H
#define AUTH_H

void loginMenu();

#endif
