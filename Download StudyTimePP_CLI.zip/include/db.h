#ifndef DB_H
#define DB_H

bool connectToDatabase();

#endif
