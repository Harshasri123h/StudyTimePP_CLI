# StudyTime++ (C++ CLI App)

**StudyTime++** is a terminal-based productivity and study tracking system for **teachers** and **students**, built in **C++** with **SQLite**.

## 📌 Features

### 👨‍🏫 Teachers
- View student study logs
- Set subject-specific goals
- Track goal completion and streaks
- Export reports to CSV

### 👨‍🎓 Students
- Log study sessions
- View progress vs. daily goals
- Check streaks and study summaries

## 🛠 Technologies
- C++17
- SQLite3
- Terminal-based UI

## 📁 Project Structure
```
├── src/
├── include/
├── data/
├── build/
└── README.md
```

## 🔧 Compile Instructions
Coming soon...

